from PIL import Image

def en_hide(enc_img,option=1):
    # Creating an Image Object
    enc_img = Image.open(enc_img)
    # Loading pixel values of original image, each entry is pixel value ie., RGB values as sublist
    enc_pixelMap = enc_img.load()
    # Creating an empty String for our hidden message
    msg = ""
    msg_index = 0

    if option ==2:
        # Traversing through the pixel values
        for row in range(enc_img.size[0]):
            for col in range(enc_img.size[1]):
                # Fetching RGB value a pixel to sublist
                list = enc_pixelMap[row, col]
                g = list[1]
                if col == 0 and row == 0:
                    msg_len = g
                elif msg_len > msg_index:
                    # Reading the message from R value of pixel
                    msg = msg + chr(g)  # Converting to charac
                    msg_index = msg_index + 1
    else:    
        # Traversing through the pixel values
        for row in range(enc_img.size[0]):
            for col in range(enc_img.size[1]):
                # Fetching RGB value a pixel to sublist
                list = enc_pixelMap[row, col]
                r = list[0]
                if col == 0 and row == 0:
                    msg_len = r
                elif msg_len > msg_index:
                    # Reading the message from R value of pixel
                    msg = msg + chr(r)  # Converting to charac
                    msg_index = msg_index + 1
    enc_img.close()
    return msg


def hide_image(path, msg,option=1):

    # Creating a image object
    org_img = Image.open(path)
    # Loading pixel values of original image, each entry is pixel value ie., RGB values as sublist
    org_pixelMap = org_img.load()

    # Creating new image object with image mode and dimensions as that of original image
    enc_img = Image.new(org_img.mode, org_img.size)
    enc_pixelsMap = enc_img.load()

    # Reading message to be encrypted from user
    msg_index = 0
    # Finding the lenght of messag
    msg_len = len(msg)

    if option ==2:
        # Traversing through the pixel values
        for row in range(org_img.size[0]):
            for col in range(org_img.size[1]):
                # Fetching RGB value a pixel to sublist
                list = org_pixelMap[row, col]
                r = list[0]  # R value
                g = list[1]  # G value
                b = list[2]  # B value
                if row == 0 and col == 0:
                    ascii = msg_len
                    enc_pixelsMap[row, col] = (r,ascii, b)
                elif msg_index <= msg_len:
                    # Hiding our message inside the R values of the pixel
                    c = msg[msg_index - 1]
                    ascii = ord(c)
                    enc_pixelsMap[row, col] = (r,ascii,b)
                else:  # Assigning the pixel values of old image to new image
                    enc_pixelsMap[row, col] = (r, g, b)
                msg_index += 1

    else:
        # Traversing through the pixel values
        for row in range(org_img.size[0]):
            for col in range(org_img.size[1]):
                # Fetching RGB value a pixel to sublist
                list = org_pixelMap[row, col]
                r = list[0]  # R value
                g = list[1]  # G value
                b = list[2]  # B value
                if row == 0 and col == 0:
                    ascii = msg_len
                    enc_pixelsMap[row, col] = (ascii, g, b)
                elif msg_index <= msg_len:
                    # Hiding our message inside the R values of the pixel
                    c = msg[msg_index - 1]
                    ascii = ord(c)
                    enc_pixelsMap[row, col] = (ascii, g, b)
                else:  # Assigning the pixel values of old image to new image
                    enc_pixelsMap[row, col] = (r, g, b)
                msg_index += 1

    org_img.close()
    # Display the image
    enc_img.show()
    # Save the image
    enc_img.save("encrypted_image.png")
    enc_img.close()
