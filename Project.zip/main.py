import customtkinter
from tkinter import *
from tkinter import Label, Tk
from tkinter import filedialog
from tkinter.filedialog import askdirectory
from PIL import Image, ImageTk
from encryption_algorithm import encryption_algorithm
from hide import *

customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("blue")


class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        self.title("AES hided in photo encryption and decryption")
        self.geometry("1050x625")
        self.protocol(
            "WM_DELETE_WINDOW", self.on_closing
        )  # call .on_closing() when app gets closed

        # create sidebar frame with widgets

        self.sidebar_frame = customtkinter.CTkFrame(self, width=140, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, rowspan=2, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(5, weight=1)

        self.logo_label = customtkinter.CTkLabel(
            self.sidebar_frame, text="Operations", text_font=("Roboto", -16)
        )
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))

        self.sidebar_textbox = Text(
            self.sidebar_frame, font="Segoe", width=16, height=2
        )
        self.sidebar_textbox.grid(
            row=1, column=0, padx=(10, 20), pady=(20, 10), sticky="new"
        )
        self.sidebar_get_key = customtkinter.CTkButton(
            self.sidebar_frame, command=self.get_secret_code,text_font="Segoe"
        )
        self.sidebar_get_key.grid(row=2, column=0, padx=20, pady=10)

        self.sidebar_button_1 = customtkinter.CTkButton(
            self.sidebar_frame, command=self.encrypt_fun,text_font="Segoe"
        )
        self.sidebar_button_1.grid(row=3, column=0, padx=20, pady=10)

        self.sidebar_button_2 = customtkinter.CTkButton(
            self.sidebar_frame, command=self.decrypt_fun,text_font="Segoe"
        )
        self.sidebar_button_2.grid(row=4, column=0, padx=10, pady=10)

        self.sidebar_button_3 = customtkinter.CTkButton(
            self.sidebar_frame, command=self.hide,text_font="Segoe"
        )
        self.sidebar_button_3.grid(row=5, column=0, padx=10, pady=10)

        self.sidebar_button_4 = customtkinter.CTkButton(
            self.sidebar_frame, command=self.show,text_font="Segoe"
        )
        self.sidebar_button_4.grid(row=6, column=0, padx=10, pady=10)

        self.appearance_mode_label = customtkinter.CTkLabel(
            self.sidebar_frame, text="Appearance Mode:", anchor="w",text_font="Segoe"
        )
        self.appearance_mode_label.grid(row=7, column=0, padx=10, pady=(10, 0))

        self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(
            self.sidebar_frame,
            values=["Light", "Dark", "System"],
            command=self.change_appearance_mode,
        )
        self.appearance_mode_optionemenu.grid(row=8, column=0, padx=10, pady=(10, 10))

        self.scaling_label = customtkinter.CTkLabel(
            self.sidebar_frame, text="UI Scaling:", anchor="w",text_font="Segoe"
        )
        self.scaling_label.grid(row=9, column=0, padx=10, pady=(10, 0))


        self.scaling_optionemenu = customtkinter.CTkOptionMenu(
            self.sidebar_frame,
            values=["80%", "90%", "100%", "110%", "120%"],
            command=self.change_scaling,
        )
        self.scaling_optionemenu.grid(row=10, column=0, padx=10, pady=(10, 20))

        #encrypt key
        self.encrypt_static_frame = customtkinter.CTkFrame(self)
        self.encrypt_static_frame.grid(
            row=0, column=3, padx=(20, 10), rowspan=2, pady=(20, 10), sticky="nsew"
        )
        self.button_encrypt = customtkinter.CTkButton(
            self.encrypt_static_frame, command=self.encryptMyKey,text_font="Segoe"
        )
        self.button_encrypt.grid(row=2, column=0, padx=(20, 10), pady=(20, 10), sticky="nw")
        self.button_encrypt.configure(text="encryptMyKey")
        
        self.button_hideMyKey = customtkinter.CTkButton(
            self.encrypt_static_frame, command=self.hideMyKey,text_font="Segoe"
        )
        self.button_hideMyKey.configure(text="hideMyKey")
        self.button_hideMyKey.grid(row=3, column=0, padx=(20, 10), pady=(20, 10), sticky="nw")
        
        self.button_showMyKey = customtkinter.CTkButton(
            self.encrypt_static_frame, command=self.showMyKey,text_font="Segoe"
        )
        self.button_showMyKey.configure(text="showMyKey")
        self.button_showMyKey.grid(row=4, column=0, padx=(20, 10), pady=(20, 10), sticky="nw")        

        self.button_decryptMyKey = customtkinter.CTkButton(
            self.encrypt_static_frame, command=self.decryptMyKey
            ,text_font="Segoe"        )
        self.button_decryptMyKey.configure(text="decryptMyKey")
        self.button_decryptMyKey.grid(row=5, column=0, padx=(20, 10), pady=(20, 10), sticky="nw")

        self.labe8 = customtkinter.CTkLabel(
            self.encrypt_static_frame, text="encrypted my key",anchor="w",text_font="Segoe")
        
        self.labe8.grid( row=0, column=0, padx=10, pady=(10, 0) )
        
        self.textbox5 = customtkinter.CTkEntry(
                    self.encrypt_static_frame,
                    width=150,height=30,text_font="Segoe")
        self.textbox5.grid(row=1, column=0, padx=(10, 10),pady=(10, 10),sticky="nw")
       
       
        self.labe9 = customtkinter.CTkLabel(
            self.encrypt_static_frame, text="decrypted my key",anchor="w",text_font="Segoe")
        self.labe9.grid( row=6, column=0, padx=10, pady=(10, 0))

        self.textbox6 = customtkinter.CTkEntry(
                    self.encrypt_static_frame,width=150,height=30,)
        self.textbox6.grid(row=7, column=0, padx=(10, 10), pady=(10, 10), sticky="nw")


        #end eclkfdjglfdkmjglkfdglda

        # Werring Label
        self.werring_frame = customtkinter.CTkFrame(self)
        self.werring_frame.grid(
            row=3, column=0, padx=(5, 10), columnspan=3, pady=(5, 10), sticky="nsew"
        )
        self.lable_erorr = customtkinter.CTkLabel(
            self.werring_frame,text="erroe we appear here",anchor="w",text_font="Segoe"
        )
        self.lable_erorr.grid(row=0, column=1, padx=(5, 5), pady=(5, 5), sticky="nw")
        

        self.textbox_frame = customtkinter.CTkFrame(self)
        self.textbox_frame.grid(
            row=0, column=1, padx=(20, 10), columnspan=2, pady=(20, 10), sticky="nsew"
        )

        self.lable_msg = customtkinter.CTkLabel(
            self.textbox_frame,text="Enter Your message",anchor="w",text_font="Segoe"
        )
        self.lable_msg.grid(row=0, column=0, padx=(5, 5), pady=(5, 5), sticky="nw")

        self.textbox = customtkinter.CTkEntry(
            self.textbox_frame,  text_font="Segoe",width=300, height=70
        )
        self.textbox.grid(row=1, column=0,  padx=(5, 5), pady=(5, 5), sticky="nw")
        
        self.lable_encrypt = customtkinter.CTkLabel(
            self.textbox_frame,text="Your message Encrpted",anchor="w",text_font="Segoe"
        )
        self.lable_encrypt.grid(row=0, column=1, padx=(5, 5), pady=(5, 5), sticky="nw")
        self.textbox2 = customtkinter.CTkEntry(
            self.textbox_frame, width=300, height=70,text_font="Segoe"
        )

        self.textbox2.grid(row=1, column=1,  padx=(5, 5), pady=(5, 5), sticky="ne")

        self.sidebar_button_111 = customtkinter.CTkButton(
            self.textbox_frame, command=self.clear1
        )
        self.sidebar_button_111.grid(row=2, column=0, padx=5, pady=5)

        self.sidebar_button_222 = customtkinter.CTkButton(
            self.textbox_frame, command=self.clear2
        )
        self.sidebar_button_222.grid(row=2, column=1, padx=5, pady=5)

        self.slider_progressbar_frame = customtkinter.CTkFrame(self)
        self.slider_progressbar_frame.grid(
            row=1, column=1, columnspan=2, padx=(20, 10), pady=(10, 10), sticky="nsew"
        )
        self.slider_progressbar_frame.grid_columnconfigure(0, weight=1)
        self.slider_progressbar_frame.grid_rowconfigure(3, weight=1)

        self.label = Label(
            self.slider_progressbar_frame, text="image", width=20, height=20
        )
        self.label.grid(
            row=0, column=0, columnspan=3, padx=20, pady=(20, 10), sticky="ew"
        )
        self.main_button_1 = customtkinter.CTkButton(
            self.slider_progressbar_frame,
            fg_color=None,
            border_width=2,
            command=self.image,
        )
        self.main_button_1.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")

        self.sidebar_button_111.configure(text="clear")
        self.sidebar_button_222.configure(text="clear")
        self.main_button_1.configure(text="browser")
        self.sidebar_button_2.configure(text="Decrypt ")
        self.sidebar_button_1.configure(text="Encrypt ")
        self.sidebar_get_key.configure(text="Generate Key")
        self.sidebar_button_3.configure(text="Hide")
        self.sidebar_button_4.configure(text="Show")
        self.appearance_mode_optionemenu.set("Dark")
        self.scaling_optionemenu.set("80%")
        self.opencout = 0
        

    #function encrypt key
    def encryptMyKey(self):
        self.key2 = self.textbox5.get()
        if len(self.key2) <1:
            self.lable_erorr.set_text( "Please Enter The Key That use for Encryption .")
        else:
            e = encryption_algorithm()
            text =  self.key 
            print(text)
            with open("key.txt", "w") as f:
                f.write(text)
            e.encrypt("key.txt", self.key2)
            f = open("crypted_key.txt", "rb")
            d = f.read().decode(errors="replace")
            self.textbox6.delete(0, END)
            self.textbox6.insert(0, str(d))
            self.sidebar_textbox.delete(1.0, END)
            self.key = 0;
            # self.sidebar_textbox.insert(1.0, END)

    def decryptMyKey(self):
        self.textbox6.delete(0, END)
        self.key2 = self.textbox5.get()
        if len(self.key2) <1:
            self.lable_erorr.set_text( "Please Enter The Key That use for Encryption .")
        else:
            d = encryption_algorithm()
            d.decypher("crypted_key.txt", 2, self.key2)
            f = open("decrypted_crypted_key.txt", "rb")
            d = f.read().decode(errors="replace")
            self.sidebar_textbox.delete(1.0, END)
            self.sidebar_textbox.insert(1.0, d)
            self.key =str(d)
            print(self.key)
            # self.textbox6.delete(0, END)
            self.textbox6.insert(0, d)


    def showMyKey(self):
        self.key2 = self.textbox5.get()
        if len(self.key2) <1:
            self.lable_erorr.set_text( "Please Enter The Key That use for Encryption .")
        else:
            de = en_hide(self.path,2)
            e = encryption_algorithm()
            with open("key.txt", "w") as f:
                f.write(de)
            e.encrypt("key.txt", self.key2)
            f = open("crypted_key.txt", "rb")
            d = f.read().decode(errors="replace")
            self.textbox6.delete(0, END)
            self.textbox6.insert(0, d)
    
    def hideMyKey(self):
        if self.opencout <=1:
            self.lable_erorr.set_text( "Please Enter The Encrypted Image .")
        else:
            d = encryption_algorithm()
            d.decypher("crypted_key.txt", 2, self.key2)
            f = open("decrypted_crypted_key.txt", "rb")
            d = f.read().decode(errors="replace")
            self.textbox6.delete(0, END)
            hide_image(self.path, d,2)


    def open_input_dialog(self):
        self.opencout = self.opencout+1
        dialog = customtkinter.CTkInputDialog(
            master=None, text="Type in a number:", title="CTkInputDialog"
        )
        print("CTkInputDialog:", dialog.get_input())

    def change_appearance_mode(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)

    def change_scaling(self, new_scaling: str):
        new_scaling_float = int(new_scaling.replace("%", "")) / 100
        customtkinter.set_spacing_scaling(new_scaling_float)
        customtkinter.set_widget_scaling(new_scaling_float)

    def sidebar_button_callback(self):
        print("sidebar_button click")

    def on_closing(self, event=0):
        self.destroy()

    def image(self):
        self.opencout += 1
        ifile = filedialog.askopenfile(
            parent=self,
            mode="rb",
            title="Choose a file",
            filetypes=[("Image File", ".png")],
        )
        self.path = ifile.name
        self.image2 = PhotoImage(file=self.path)
        self.label.configure(image=self.image2, width=550, height=300)
        self.label.image = self.image2

    def get_secret_code(self):
        import random, string

        secret_code = "".join(
            random.choice(
                string.ascii_uppercase + string.ascii_lowercase + string.digits
            )
            for _ in range(16)
        )
        self.key = secret_code
        self.sidebar_textbox.delete(1.0, END)
        self.sidebar_textbox.insert(1.0, secret_code)

    def encrypt_fun(self):
        e = encryption_algorithm()
        text = self.textbox.get()
        print(text)
        with open("input.txt", "w") as f:
            f.write(text)
        e.encrypt("input.txt", self.key)
        f = open("crypted_input.txt", "rb")
        d = f.read().decode(errors="replace")

        self.textbox2.delete(0, END)
        self.textbox2.insert(0, str(d))


    def clear1(self):
        self.textbox.delete(0, END)

    def clear2(self):
        self.textbox2.delete(0, END)

    def show(self):
        if self.opencout <=0:
            self.lable_erorr.set_text( "Please Enter The Encrypted Image .")
        else:            
            de = en_hide(self.path)
            e = encryption_algorithm()
            with open("input.txt", "w") as f:
                f.write(de)
            e.encrypt("input.txt", self.key)
            f = open("crypted_input.txt", "rb")
            d = f.read().decode(errors="replace")
            self.textbox2.delete(0, END)
            self.textbox2.insert(0, d)

    def hide(self):
        if self.opencout ==0:
            self.lable_erorr.set_text( "Please Select Image use for hide .")
        else:    
            d = encryption_algorithm()
            d.decypher("crypted_input.txt", 2, self.key)
            f = open("decrypted_crypted_input.txt", "rb")
            d = f.read().decode(errors="replace")
            hide_image(self.path, d)
            # self.image2 = PhotoImage(file="encrypted_image.png")
            # self.label2.configure(image=self.image2, width=750, height=500)
            # self.label2.image = self.image2

    def decrypt_fun(self):
        d = encryption_algorithm()
        d.decypher("crypted_input.txt", 2, self.key)

        f = open("decrypted_crypted_input.txt", "rb")
        d = f.read().decode(errors="replace")
        self.textbox.delete(0, END)
        self.textbox.insert(0, d)


if __name__ == "__main__":
    app = App()
    app.mainloop()
