To run this project, follow the steps below
-------------------------------------------------------------
Step 1. Open folder project in computer.

Step 2: Install dependencies 
pip install -r requirements.txt

 
Step 3: You can now open project folder in your editor

Step 4: Run Project
python main.py


